**/templates** 

Currently only used for testing template views before inserting them into the index.html file in the app root directory.
